<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Bobot extends Model
{
    //
    protected $table = 'tbl_bobot';
    protected $fillable = ['bobot','nilai'];

}
