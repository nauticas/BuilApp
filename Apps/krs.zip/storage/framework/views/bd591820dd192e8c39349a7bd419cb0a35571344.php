<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="box">
        <div class="box-header with-border">
            <h4 class=""><?php echo e($title); ?></h4>
            <p class="category"></p>
        </div>
        <div class="content">

            <?php if(count($khs)>0): ?>
            <table class="table table-bordered table-condensed">
                <thead>
                    <tr class="text-center">
                        <th>Kode MK</th>
                        <th>Mata Kuliah</th>
                        <th>Semester</th>
                        <th>SKS</th>
                        <th>Nilai</th>
                        <th>Bobot</th>
                        <th>SKS x Bobot</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $total_sks =0;$total_bobot = 0;$total_ipk = 0 ?>
                    <?php $__currentLoopData = $khs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>                            
                    <tr>
                        <td colspan="7"> Semester <?php echo e($value->semester); ?> </td>
                    </tr>
                    <?php $__currentLoopData = $value->krsdetil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$detil): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php if(isset($detil->nilai)): ?>
                    <tr>
                        <td><?php echo e($detil->jadwal->matakuliah->kd_mk); ?></td>
                        <td><?php echo e($detil->jadwal->matakuliah->nama_mk); ?></td>
                        <td><?php echo e($detil->jadwal->matakuliah->semester); ?></td>
                        <td><?php echo e($detil->jadwal->matakuliah->sks); ?></td>
                        <?php 
                        $total_bobot_mk = $detil->jadwal->matakuliah->sks * $detil->nilai['bobot']['bobot'];
                        $total_sks = $total_sks + $detil->jadwal->matakuliah->sks; 
                        $total_bobot = $total_bobot+$total_bobot_mk;
                        ?>
                        <td class="text-center"><?php echo e($detil->nilai['bobot']['nilai']); ?></td>
                        <td class="text-center"><?php echo e($detil->nilai['bobot']['bobot']); ?></td>
                        <td class="text-center"><?php echo e($total_bobot_mk); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php $ip_semester =round($total_bobot/$total_sks,2); ?>
                    <tr>
                        <td colspan="2">Jumlah SKS </td>
                        <td colspan="1" class="text-center"><?php echo e($total_sks); ?></td>
                        <td colspan="3">IP Semester</td>
                        <td colspan="1" class="text-center"><?php echo e($ip_semester); ?></td>
                    </tr>

                    <?php 
                    $total_semester = $loop->count;
                    $total_ipk = $total_ipk + $ip_semester ;

                    $total_sks = 0;
                    $total_bobot_mk = 0;
                    $total_bobot = 0;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td colspan="6" >IPK</td>
                        <td class="text-center"><?php echo e(round($total_ipk / $total_semester,2)); ?></td>
                    </tr>
                </tbody>
            </table>
            <?php else: ?>
            <em class="text-info">Belum ada data nilai!</em>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>