<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="box">
        <div class="box-header with-border">
            <h4 class=""><?php echo e($title); ?></h4>
            <p class="category"></p>
        </div>
        <div class="content">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>NIM</label>
                        <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->nim); ?>" name="nim" disabled>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tahun Ajaran</label>
                        <input type="text" class="form-control border-input" value="<?php echo e($thn_ajaran->keterangan); ?>" name="thn_ajaran" disabled>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->nama_mahasiswa); ?>" name="nama_mahasiswa" disabled>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>IP Semester Tahun Lalu</label>
                        <input type="text" class="form-control border-input" value="<?php echo e($ipk->IPK); ?>" name="thn_ajaran" disabled>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Beban Study Maks</label>
                        <input type="text" class="form-control border-input" value="<?php echo e($beban_studi); ?>" name="thn_ajaran" disabled>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Jurusan</label>
                        <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->jurusan); ?>" name="jurusan" disabled>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Program</label>
                        <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->kelas_program); ?>" name="kelas_program" disabled>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Dosen Wali</label>
                        <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->dosen->nama_dosen); ?>" name="nama_dosen" disabled>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Semester Yang Akan Ditempuh</label>
                        <input type="text" class="form-control border-input" value="<?php echo e($semester); ?>" name="kelas_program" disabled>
                    </div>
                </div>
            </div>
            <form name="isi_krs" method="POST" action="<?php echo e(!isset($krs) ? route('krs.store') : route('krs.update',$krs->id)); ?>">
                <?php echo e(csrf_field()); ?>

                <?php if(isset($krs)): ?>
                <input type="hidden" name="_method" value="put">
                <?php endif; ?>
                <table class="table table-bordered table-condensed">
                    <thead>
                        <tr>
                            <th colspan="12" class="text-center">MATA KULIAH YANG AKAN DITEMPUH PADA SEMESTER INI :</th>
                        </tr>
                        <tr>
                            <th>Kode Mata Kuliah</th>
                            <th>Mata Kuliah</th>
                            <th>Semester</th>
                            <th>SKS</th>
                            <th colspan="2">Dosen</th>
                            <th>Kelas</th>
                            <th>Jadwal</th>
                            <th>Quota</th>
                            <th>Peserta</th>
                            <th>Calon Peserta</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td rowspan="<?php echo e($mk->jadwal->count()+1); ?>"><?php echo e($mk->kd_mk); ?></td>
                            <td rowspan="<?php echo e($mk->jadwal->count()+1); ?>"><?php echo e($mk->nama_mk); ?></td>
                            <td rowspan="<?php echo e($mk->jadwal->count()+1); ?>"><?php echo e($mk->semester); ?></td>
                            <td rowspan="<?php echo e($mk->jadwal->count()+1); ?>"><?php echo e($mk->sks); ?></td>
                        </tr>
                        <?php $__currentLoopData = $mk->jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td><?php echo e($jadwal->dosen->kode_dosen); ?></td>
                            <td><?php echo e($jadwal->dosen->nama_dosen); ?></td>
                            <td><?php echo e($jadwal->kelas); ?></td>
                            <td><?php echo e($jadwal->jadwal.' / '.$jadwal->ruang->nama_ruang); ?></td>
                            <td><?php echo e($jadwal->kapasitas); ?></td>
                            <td><?php if($peserta[$jadwal->id] > 0): ?>
                                <a href="<?php echo e(route('krs.peserta',$jadwal->id)); ?>"><?php echo e($peserta[$jadwal->id]); ?></a>
                                <?php else: ?>
                                <?php echo e($peserta[$jadwal->id]); ?>

                                <?php endif; ?></td>
                                <td>
                                    <?php if($calon_peserta[$jadwal->id] > 0): ?>
                                    <a href="<?php echo e(route('krs.calonpeserta',$jadwal->id)); ?>"><?php echo e($calon_peserta[$jadwal->id]); ?></a>
                                    <?php else: ?>
                                    <?php echo e($calon_peserta[$jadwal->id]); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="checkbox <?php if(isset($krs_jadwal)): ?> <?php if(array_key_exists($jadwal->id,$krs_jadwal)): ?> checked <?php endif; ?> <?php endif; ?>">
                                        <input type="checkbox" name="jadwal[<?php echo e($mk->id); ?>]" value="<?php echo e($jadwal->id); ?>" id="<?php echo e($mk->id.'-'.$jadwal->id.'-'.$mk->sks); ?>" class="cb_jadwal-<?php echo e($mk->id); ?>" <?php if(isset($krs_jadwal)): ?> <?php if(array_key_exists($jadwal->id,$krs_jadwal)): ?> checked <?php endif; ?> <?php endif; ?>>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td colspan="10">Total SKS Yang Akan Ditempuh :</td>
                                <td colspan="2"><span id="sks">0</span> SKS</td>
                            </tr>
                        </tbody>
                    </table>
                    <?php if($matakuliah): ?>
                    <input type="submit" class="btn btn-success" value="Simpan Data Kartu Rencana Study">
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
    @parent
    <script>
    var max_sks = "<?php echo e($beban_studi); ?>";
    var src = {};
    var sks = 0;
    $("input:checkbox").each(function(e){
     var $this = $(this);
     if(this.checked){
        var parse = this.id.split('-');
        src[parse[0]] = this.id;
        sks = sks + parseInt(this.id.split('-')[2]);
        $('#sks').text(sks);
    }
})
    $("input:checkbox").change(function(e) {
     sks  = 0;
     var $this = $(this);
     if(this.checked){
        var kelas = $(e.target).attr('class');
        $('.'+kelas).not(this).parent().closest('div').attr('class','checkbox');
        $('.'+kelas).not(this).attr('checked',false);
        var parse = e.target.id.split('-');
        src[parse[0]] = e.target.id;
    } else {
        var parse = e.target.id.split('-');
        src[parse[0]] = '';
    }
    $.each(src,function(key,value){
        if(value) {
            sks = sks + parseInt(value.split('-')[2]);
        }
    });
    if(sks < 0){
        sks = 0;
    }
    if(sks > parseInt(max_sks)){
        alert('Maksimal Beban Studi');
        $('.'+kelas).parent().closest('div').attr('class','checkbox');
        $('.'+kelas).attr('checked',false);
        var parse = e.target.id.split('-');
        src[parse[0]] = '';
    } else {
        $('#sks').text(sks);
    }
    sks = 0;
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>