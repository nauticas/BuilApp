<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="box">
        <div class="box-header with-border">
            <h4 class=""><?php echo e($title); ?></h4>
            <p class="category"></p>
        </div>
        <div class="content table-responsive table-full-width">
            <table class="table table-striped">
                <thead>
                    <th>Nama Ruang</th>
                    <th>Aksi</th>
                    <th><a href="<?php echo e(route('ruang.create')); ?>" class="btn btn-success"><span class="fa fa-plus"></span> Tambah Ruang</a></th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rg): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <form action="<?php echo e(route('ruang.destroy',$rg->id)); ?>" method="post"  class="form-inline">
                        <tr>
                            <td><?php echo e($rg->nama_ruang); ?></td>
                            <td colspan="2">
                                <a href="<?php echo e(route('ruang.edit',$rg->id)); ?>" class="btn btn-info"><i class="fa fa-pencil"></i></a>
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="delete" >
                                <button type="submit" class="btn btn-danger"><i class="fa fa-close"></i></a>
                            </td>
                        </tr>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            <?php echo e($ruang->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>