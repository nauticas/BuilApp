<?php if(Auth::check()): ?>
<aside class="main-sidebar">

  <section class="sidebar">

    <div class="user-panel">
      <div class="pull-left image">
        <img src="<?php echo e(asset('dist/img/avatar5.png')); ?>" class="img-circle" alt="User Image">
    </div>
    <div class="pull-left info">
        <p>
            <?php if(Auth::user()->role == "admin"): ?>
            <?php echo e(Auth::user()->username); ?>

            <?php elseif(Auth::user()->role == "dosen"): ?>
            <?php echo e(Auth::user()->dosen->nama_dosen); ?>

            <?php elseif(Auth::user()->role == "mahasiswa"): ?>
            <?php echo e(Auth::user()->mahasiswa->nama_mahasiswa); ?>

            <?php endif; ?>
        </p>
        <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
    </div>
</div>

<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MENU</li>
  <?php if(Auth::user()->role == 'admin'): ?>
  <li class="<?php echo e(Request::segment(2) == '' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('admin')); ?>">
        <i class="fa fa-dashboard"></i>
        <span>Dashboard</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'dosen' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('dosen.index')); ?>">
        <i class="fa fa-list"></i>
        <span>Dosen</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'mahasiswa' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('mahasiswa.index')); ?>">
        <i class="fa fa-graduation-cap"></i>
        <span>Mahasiswa</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'matakuliah' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('matakuliah.index')); ?>">
        <i class="fa fa-file-text"></i>
        <span>Mata Kuliah</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'ruang' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('ruang.index')); ?>">
        <i class="fa fa-map"></i>
        <span>Ruang</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'jadwal' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('jadwal.index')); ?>">
        <i class="fa fa-table"></i>
        <span>Jadwal Kuliah</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'thnajaran' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('thnajaran.index')); ?>">
        <i class="fa fa-calendar"></i>
        <span>Tahun Ajaran</span>
    </a>
</li>
<?php elseif(Auth::user()->role == 'mahasiswa'): ?>

<li class="<?php echo e(Request::segment(2) == '' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('mahasiswa')); ?>">
        <i class="fa fa-dashboard"></i>
        <spanp>Dashboard</spanp>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'krs' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('krs.index')); ?>">
        <i class="fa fa-id-card"></i>
        <span>Kartu Rencana Studi</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'khs' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('khs.index')); ?>">
        <i class="fa fa-vcard"></i>
        <span>Kartu Hasil Studi</span>
    </a>
</li>
<?php else: ?>

<li class="<?php echo e(Request::segment(2) == '' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('dosen')); ?>">
        <i class="fa fa-dashboard"></i>
        <span>Dashboard</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'persetujuan' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('persetujuan.index')); ?>">
        <i class="fa fa-check-square"></i>
        <span>Persetujuan KRS</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'nilai' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('nilai.index')); ?>">
        <i class="fa fa-pencil-square"></i>
        <span>Input Nilai</span>
    </a>
</li>
<?php endif; ?>

</ul>
</section>
</aside>

<?php endif; ?>