<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="box">
        <div class="box-header with-border">
            <h4 class=""><?php echo e($title); ?></h4>
            <p class="category"></p>
        </div>
        <div class="content table-responsive table-full-width">

            <?php if(count($mahasiswa)>0): ?>
            <table class="table table-striped">
                <thead>
                    <th>NIM</th>
                    <th>Nama mahasiswa</th>
                    <th>Jurusan</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    
                    <tr>
                        <td><?php echo e($mhs->nim); ?></td>
                        <td><?php echo e($mhs->nama_mahasiswa); ?></td>
                        <td><?php echo e($mhs->jurusan); ?></td>
                        <td><?php echo e($mhs->krs->first() ? $mhs->krs->first()->status : 'Belum KRS'); ?></td>
                        <td>
                            <?php if($mhs->krs->first()): ?>
                            <a href="<?php echo e(route('nilai.edit',$mhs->krs->first()->id)); ?>" class="btn btn-success">Masukkan Nilai</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <em class="text-info">Belum ada data!</em>
        <?php endif; ?>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>