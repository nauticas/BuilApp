<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="box">
        <div class="box-header with-border">
            <h4 class=""><?php echo e($title); ?></h4>
            <p class="category"></p>
        </div>
        <div class="content">
            <div class="col-md-6">
                <div class="row">
                    <div class="form-group">
                        <div class="col-sm-3">
                          <p class="form-control-static">NIM</p>
                      </div>
                      <div class="col-sm-9">
                          <p class="form-control-static">: <?php echo e($krs->mahasiswa->nim); ?></p>
                      </div>
                  </div>
              </div>
              <div class="row">
                <div class="form-group">
                    <div class="col-sm-3">
                      <p class="form-control-static">Nama</p>
                  </div>
                  <div class="col-sm-9">
                      <p class="form-control-static">: <?php echo e($krs->mahasiswa->nama_mahasiswa); ?></p>
                  </div>
              </div>
          </div>
          <div class="row">
            <div class="form-group">
                <div class="col-sm-3">
                  <p class="form-control-static">Jurusan</p>
              </div>
              <div class="col-sm-9">
                  <p class="form-control-static">: <?php echo e($krs->mahasiswa->jurusan); ?></p>
              </div>
          </div>
      </div>
      <div class="row">
        <div class="form-group">
            <div class="col-sm-3">
              <p class="form-control-static">Dosen Wali</p>
          </div>
          <div class="col-sm-9">
              <p class="form-control-static">: <?php echo e($krs->mahasiswa->dosen->nama_dosen); ?></p>
          </div>
      </div>
  </div>
</div>
<div class="col-md-6">
    <div class="row">
        <div class="form-group">
            <div class="col-sm-7">
              <p class="form-control-static">Semester Tahun Ajaran</p>
          </div>
          <div class="col-sm-5">
              <p class="form-control-static">: <?php echo e($thn_ajaran->keterangan); ?></p>
          </div>
      </div>
      <div class="form-group">
        <div class="col-sm-7">
          <p class="form-control-static">IP Semester Lalu/Beban Studi</p>
      </div>
      <div class="col-sm-5">
          <p class="form-control-static">: <?php echo e($ipk->IPK ? $ipk->IPK : 0); ?> / <?php echo e($beban_studi); ?></p>
      </div>
  </div>
</div>
<div class="row">
    <div class="form-group">
        <div class="col-sm-7">
          <p class="form-control-static">Program Kelas</p>
      </div>
      <div class="col-sm-5">
          <p class="form-control-static">: <?php echo e($krs->mahasiswa->kelas_program); ?></p>
      </div>
  </div>
</div>
<div class="row">
    <div class="form-group">
        <div class="col-sm-7">
          <p class="form-control-static">Semester</p>
      </div>
      <div class="col-sm-5">
          <p class="form-control-static">: <?php echo e($krs->semester); ?></p>
      </div>
  </div>
</div>
</div>
<table class="table table-bordered table-condensed">
    <thead>
        <tr>
            <th colspan="11" class="text-center">MATA KULIAH YANG AKAN DITEMPUH PADA SEMESTER INI :</th>
        </tr>
        <tr>
            <th>Kode MK</th>
            <th>Mata Kuliah</th>
            <th>Semester</th>
            <th>SKS</th>
            <th>Dosen</th>
            <th>Kelas</th>
            <th>Jadwal</th>
            <th>Quota</th>
            <th>Peserta</th>
            <th>Calon Peserta</th>
            <?php if($krs->status == 0): ?>
            <th>Aksi</th>
            <?php endif; ?>
        </tr>
        <?php $total_sks =0 ?>
        <?php $__currentLoopData = $krs->krsdetil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php if(!$telo->nilai): ?>
        <tr>
            <td><?php echo e($telo->jadwal->matakuliah->kd_mk); ?></td>
            <td><?php echo e($telo->jadwal->matakuliah->nama_mk); ?></td>
            <td><?php echo e($telo->jadwal->matakuliah->semester); ?></td>
            <?php 
            $total_sks = $total_sks + $telo->jadwal->matakuliah->sks; 
            ?>
            <td><?php echo e($telo->jadwal->matakuliah->sks); ?></td>
            <td><?php echo e($telo->jadwal->dosen->nama_dosen); ?></td>
            <td><?php echo e($telo->jadwal->program); ?></td>
            <td><?php echo e($telo->jadwal->jadwal); ?></td>
            <td><?php echo e($telo->jadwal->kapasitas); ?></td>
            <td><?php echo e($peserta[$telo->jadwal->id]); ?></td>
            <td><?php echo e($calon_peserta[$telo->jadwal->id]); ?></td>
            <?php if($krs->status == 0): ?>
            <form action="<?php echo e(route('persetujuan.destroy',$telo->id)); ?>"" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="DELETE">
                <td><input type="submit" value="Batalkan" class="btn btn-danger"></td>
            </form>
            <?php endif; ?>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td colspan="3">Total SKS Yang Akan Ditempuh </td>
            <td colspan="9"><?php echo e($total_sks); ?></td>
        </tr>
        <tr>
            <td colspan="3">Status Persetujuan KRS :</td>
            <td colspan="9"><?php echo e($krs->statuta); ?></td>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>
(+) Jika Anda menyetujui Rencana Study Mahasiswa yang bersangkutan silakan click tombol Setujui di bawah ini <br />
<form action="<?php echo e(route('persetujuan.update',$krs->id)); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="status" value="<?php echo e($krs->status == 0 ? 1 : 0); ?>">
    <input type="hidden" name="_method" value="put">
    <input type="submit" class="btn btn-success" value="<?php echo e($krs->status == 1 ? 'Batalkan Kartu Rencana Studi' : 'Setujui Kartu Rencana Studi'); ?>">
</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>