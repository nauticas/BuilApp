<?php $__env->startSection('content'); ?>
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title"><?php echo e($title); ?></h4>
                    <p class="category"></p>
                </div>
                <div class="content table-responsive table-full-width">
                    <table class="table table-striped">
                        <thead>
                            <th>NIM</th>
                            <th>Nama mahasiswa</th>
                            <th>Jurusan</th>
                            <th>Status</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td><?php echo e($mhs->krs->mahasiswa->nim); ?></td>
                                <td><?php echo e($mhs->krs->mahasiswa->nama_mahasiswa); ?></td>
                                <td><?php echo e($mhs->krs->mahasiswa->jurusan); ?></td>
                                <td><?php echo e($mhs->krs->statuta); ?></td>
                            </tr>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>